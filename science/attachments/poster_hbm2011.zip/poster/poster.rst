Functional brain connectivity, as revealed through distant correlations
in the signals measured by functional Magnetic Resonance Imaging (fMRI)
has been used to reveal functional segregated cognitive networks as well
as small-world properties of brain functional architecture.

We are interested in the estimation and comparison of probabilistic
models of functional connectivity from fMRI data using Gaussian graphical
models.

We learn the correlation structure of the cognitive networks between 30
regions of interests on a population of healthy control at rest.
Strongly-integrated sets of regions can be identified to resting-state
networks well-known from the literature.

We compare this graphical model to models learned on stroke patients. We
find that correlations within resting-state networks are impacted
selectively, even between regions not damaged by the focal lesion. These
connectivity perturbations seem correlated to behavioral symptoms.

To pave the road for similar analysis with many regions of interest, we
propose to address the problem of multiple comparisons by introducing
covariance selection. In the framework of Gaussian graphical models, we
learn an independence structure that generalizes well between subjects.
This amounts to a statistically-controlled pruning of our graphical
model.

We compare several covariance selection procedures: L1-penalized,
group-L1-penalized maximum likelihood, as well as greedy L0 procedures.
We test for generalization to new subjects using the multivariate normal
likelihood. We find that generalization scores are limited by
inter-subject variability and that there is a trade-off between
generalization and reducing the number of edges studied on the graph.

In the corresponding graphs, we find indications of hub nodes,
characteristic of small-world topology, as well as large structures
that we interpret as cognitive networks.
