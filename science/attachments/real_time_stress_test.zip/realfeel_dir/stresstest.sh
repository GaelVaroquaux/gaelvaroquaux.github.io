#!/bin/bash

# If the realfeel program fails try:
# "echo 1024 > /proc/sys/dev/rtc/max-user-freq" as root.

benchmark(){
    FREQ=$1
    cp realfeel.c realfeel_${FREQ}Hz.c
    sed -i "1i#define HZ $FREQ" realfeel_${FREQ}Hz.c
    gcc -O -Wall -o realfeel_${FREQ}Hz realfeel_${FREQ}Hz.c
    ./realfeel_${FREQ}Hz results/$(hostname)_${FREQ}Hz.hist &
    RFPID=$!

    for ((  i = 0 ;  i <= 10;  i++  ))
    do
	ping -c 10 www.google.com &
	dd if=/dev/urandom bs=1M count=40 | md5sum - &
	dd if=/dev/zero of=/tmp/foo bs=1M count=500
	sync
    rm /tmp/foo
    done
    kill -2 $RFPID
    rm realfeel_${FREQ}Hz.c
}

mkdir results

python pickle_data.py results/$(hostname).shelve

./hosttype > results/$(hostname).hosttype

#for freq in 32 128 512 1024
#do
#    benchmark $freq
#done

