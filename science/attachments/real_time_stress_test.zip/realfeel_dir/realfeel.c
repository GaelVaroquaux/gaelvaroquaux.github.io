/*

	Mirrored by www.captain.at
	Taken from Andrew Morton's "amlat" package available at:
	http://www.zipworld.com.au/~akpm/linux/schedlat.html

 * This was originally written by Mark Hahn.  Obtained from
 * http://brain.mcmaster.ca/~hahn/realfeel.c
 *
 * Modified 02-01-07 By Gael Varoquaux for more digits and negativ
 * jitter.
 */

#include <linux/rtc.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sched.h>
#include <sys/signal.h>
#include <string.h>

#ifndef HZ
    #define HZ 256
#endif

double second() {
	struct timeval tv;
	gettimeofday(&tv,0);
	return tv.tv_sec + 1e-6 * tv.tv_usec;
}

typedef unsigned long long u64;

u64 rdtsc() {
	u64 tsc;
	__asm__ __volatile__("rdtsc" : "=A" (tsc));
	return tsc;
}

void selectsleep(unsigned us) {
	struct timeval tv;
	tv.tv_sec = 0;
	tv.tv_usec = us;
	select(0,0,0,0,&tv);
}

double secondsPerTick, ticksPerSecond;

void calibrate() {
	double sumx = 0;
	double sumy = 0;
	double sumxx = 0;
	double sumxy = 0;
	double slope;

	// least squares linear regression of ticks onto real time
	// as returned by gettimeofday.

	const unsigned n = 30;
	unsigned i;

	for (i=0; i<n; i++) {
		double breal,real,ticks;
		u64 bticks;
	
		breal = second();
		bticks = rdtsc();

		selectsleep((unsigned)(10000 + drand48() * 200000));

		ticks = rdtsc() - bticks;
		real = second() - breal;

		sumx += real;
		sumxx += real * real;
		sumxy += real * ticks;
		sumy += ticks;
	}
	slope = ((sumxy - (sumx*sumy) / n) /
		 (sumxx - (sumx*sumx) / n));
	ticksPerSecond = slope;
	secondsPerTick = 1.0 / slope;
	printf("%3.3f MHz\n",ticksPerSecond*1e-6);
}

void fatal(char *msg) {
	perror(msg);
	exit(1);
}

int set_realtime_priority(void)
{
	struct sched_param schp;
	/*
	 * set the process to realtime privs
	 */
	memset(&schp, 0, sizeof(schp));
	schp.sched_priority = sched_get_priority_max(SCHED_FIFO);
	
	if (sched_setscheduler(0, SCHED_FIFO, &schp) != 0) {
		perror("sched_setscheduler");
		exit(1);
	}

	return 0;
}

int stopit;

#define SAMPLES	10000
int histogram[SAMPLES];		/* Milliseconds */

void hist(char *file) {
	int i;
	FILE *f;

	f = fopen(file, "w");
	if (f == 0) {
		fprintf(stderr, "realfeel: can't open `%s':%s\n",
			file, strerror(errno));
		exit(1);
	}
	for (i = 0; i < SAMPLES; i++) {
		if (histogram[i]) {
			fprintf(f, "%.2f %d\n",
				((float) i - SAMPLES/2 ) / 1000, histogram[i]);
		}
	}
	fclose(f);
	exit(0);
}

void signalled(int sig) {
	stopit = 1;
}

static void usage(void) {
	fprintf(stderr, "Usage: realfeel filename.hist\n");
	exit(1);
}

int main(int argc, char *argv[])
{
	int fd;
	int hz;
	double ideal;
	u64 last;
	double max_delay = 0;

	if (argc != 2)
		usage();

	if (mlockall(MCL_CURRENT|MCL_FUTURE) != 0) {
		perror("mlockall");
		exit(1);
	}
	set_realtime_priority();
	calibrate();
	printf("secondsPerTick=%f\n", secondsPerTick);
	printf("ticksPerSecond=%f\n", ticksPerSecond);

	fd = open("/dev/rtc",O_RDONLY);
	if (fd == -1) 
		fatal("failed to open /dev/rtc");

	hz = HZ;
	ideal = 1.0 / hz;
	if (ioctl(fd, RTC_IRQP_SET, hz) == -1)
		fatal("ioctl(RTC_IRQP_SET) failed");

	printf("%d Hz\n",hz);
	/* Enable periodic interrupts */
	if (ioctl(fd, RTC_PIE_ON, 0) == -1)
		fatal("ioctl(RTC_PIE_ON) failed");

	last = rdtsc();
	signal(SIGINT, signalled);

	while (!stopit) {
		u64 now;
		double delay;
		int data;
		int ms;

		if (read(fd, &data, sizeof(data)) == -1)
			fatal("blocking read failed");

		now = rdtsc();
		delay = secondsPerTick * (now - last);
		if (delay > max_delay) {
			max_delay = delay;
			printf("%.3f msec\n", 1e3 * (ideal - delay));
		}
		ms = (-(ideal - delay) + 1.0/20000.0) * 1000000;
		ms = ms + (float) SAMPLES/2 ;
		if (ms < 0)
			ms = 0;		/* hmmm */
		if (ms >= SAMPLES)
			ms = SAMPLES;
		histogram[ms]++;
		last = now;
	}
	if (ioctl(fd, RTC_PIE_OFF, 0) == -1)
		fatal("ioctl(RTC_PIE_OFF) failed");
	hist(argv[1]);
	return 0;
}
