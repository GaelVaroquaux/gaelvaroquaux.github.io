#!/usr/bin/python

def pickle_data(dir):
    import os, re
    import shelve
    hostname = os.popen('hostname').read()[:-1]

    data = shelve.open('results/'+hostname+'.shelve')

    data['OS'] = os.popen('uname -s').read()[:-1]
    data['OSversion'] = os.popen('uname -v').read()[2:-1]
    data['OSrelease'] = os.popen('uname -r').read()[:-1]

    try:
        cpuinfo = file('/proc/cpuinfo').read()
        data['bogomips'] = float(re.search(r'\nbogomips\t: (.*)\n',
                                    cpuinfo).group(1))
        data['cpu MHz'] = float(re.search(r'\ncpu MHz\t\t: (.*)\n',
                                    cpuinfo).group(1))
        data['cpu name'] = re.search(r'\nmodel name\t: (.*)\n',
                                    cpuinfo).group(1)
        data['cache size KB'] = re.search(r'\ncache size\t: (.*) KB\n',
                                    cpuinfo).group(1)
        data['CPU number'] = len(re.findall(r'processor\t: (.*)\n', cpuinfo))
    except:
        pass

    try:
        meminfo = file('/proc/meminfo').read()
        data['mem Mb'] = int(re.search(r'MemTotal:(.*) kB\n',
                                        meminfo).group(1))/1024
    except:
        pass

    data.close()

import sys

pickle_data(sys.argv[1])

