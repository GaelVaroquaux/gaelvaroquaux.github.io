#!/usr/bin/python

import matplotlib
#matplotlib.use('ps')
from pylab import *
from scipy import *
    
import glob, shelve, re, os, copy, sys

results = {}

specs = {}

def print_dic(dic):
    for key, value in dic.iteritems():
        if isinstance(value, float):
            print ":%s:\n\t%f" % (key, value)
        else:
            print ":%s:\n\t%s" % (key, value.__str__())

for filename in glob.glob('results/*.hist'):
    print "processing %s" % filename
    hostname, freq = re.search(r'results/(.*)_(\d*)Hz.hist$', filename).groups()
    data = shelve.open('results/' + hostname + '.shelve')
    freq = float(freq)

    h = io.read_array(filename)
    h = h.reshape((-1,2))

    if not hostname in results:
        results[hostname] = {}
        specs[hostname] = {}
        for key, value in data.iteritems():
            specs[hostname][key] = value
    results[hostname][freq]=h

    # Evaluate the number of events missed:
    times = h[:,0]
    numbers = h[:,1]
    if not 'fraction missed' in specs[hostname]:
        specs[hostname]['fraction missed'] = {} 
    specs[hostname]['fraction missed'][freq] = sum(
                            numbers[abs(times/1000.*float(freq))>1])/sum(numbers)

number_plots_x = len(results.keys())
number_plots_y = len(results[hostname].keys())

params = {#'backend': 'ps',
          'axes.labelsize': 16,
          'text.fontsize': 16,
          'xtick.labelsize': 12,
          'ytick.labelsize': 12}
rcParams.update(params)

colors = ['r.', 'b.', 'g.', 'k.']
for hostname, result in results.iteritems():
    clf()
    hold(True)
    keys = result.keys()
    keys.sort(reverse=True)
    for y,freq in enumerate(keys):
        h = result[freq]
        semilogy(h[:,0]*freq/1000., h[:,1], colors[y])
    legend(map(lambda x: '%dHz' %x, keys), loc='upper right')
    ax = gca()
    text(0.01, 0.95,'%dx %s, \n%s %s\n %s\n%s'
                %(specs[hostname]['CPU number'],specs[hostname]['cpu name'], 
                  specs[hostname]['OS'],
                  specs[hostname]['OSrelease'], specs[hostname]['OSversion'],
                  hostname),
                fontsize = 12,
                horizontalalignment='left', verticalalignment='top',
                transform = ax.transAxes)
    epsfilename =  'results/'+hostname+'.eps'
    savefig(epsfilename)
    os.system('epstopdf %s' % epsfilename) 

params = {#'backend': 'ps',
          'axes.labelsize': 10,
          'text.fontsize': 10,
          'xtick.labelsize': 8,
          'ytick.labelsize': 8}
rcParams.update(params)


resultsfile = file('specs.rst', 'w')
sys.stdout = resultsfile
for hostname in results.keys():
    print "\n*%s*\n" % hostname
    print_dic(specs[hostname])
sys.stdout = sys.__stdout__

def outfig(figname):
    clf()
    hold(True)
    colors = ['r.', 'b.', 'g.', 'k.']
    for x, (hostname, result) in enumerate(results.iteritems()):
        subplot(number_plots_x, 1, x+1)
        keys = result.keys()
        keys.sort(reverse=True)
        for y, freq in enumerate(keys):
            h = result[freq]
            semilogy(h[:,0]*freq/1000., h[:,1], colors[y])
        ax = gca()
        axis([-1, 1, 0.1, 100])
        ax.autoscale_view(scalex=False)
        draw()
        text(0.99, 0.95,
            'Fraction missed: @1024Hz %.1e\n@512Hz %.1e\n@128Hz %.1e\n@32Hz %.1e'
                    % (specs[hostname]['fraction missed'][1024],
                       specs[hostname]['fraction missed'][512],
                       specs[hostname]['fraction missed'][128],
                       specs[hostname]['fraction missed'][32],
                        ),
                    fontsize = 8, color=(0.4, 0.4, 0.4),
                    horizontalalignment='right', verticalalignment='top',
                    transform = ax.transAxes)
        text(0.01, 0.95,'%dx %s, \n%s %s\n %s\n %dMb\n%s'
                    %(specs[hostname]['CPU number'],
                    specs[hostname]['cpu name'],
                    specs[hostname]['OS'],
                    specs[hostname]['OSrelease'], specs[hostname]['OSversion'],
                    specs[hostname]['mem Gb'],
                    hostname),
                    fontsize = 8, color=(0.4, 0.4, 0.4),
                    horizontalalignment='left', verticalalignment='top',
                    transform = ax.transAxes)
    #legend(map(lambda x: '%dHz' %x, keys), loc='upper right')
    legend(map(lambda x: '%dHz' %x, keys), loc= (0.8, -0.5))
    #show()
    savefig(figname)

outfig('results.eps')
os.system('epstopdf results.eps')

#matplotlib.use('wxAgg')
#params = {'backend': 'wxAgg'}
#rcParams.update(params)
outfig('results.png')

