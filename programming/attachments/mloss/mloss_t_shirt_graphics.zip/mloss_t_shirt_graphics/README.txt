Graphics for the MLOSS 2015 t-shirts, by Gael Varoquaux.

The robot is originally based on
https://openclipart.org/detail/204541/nutch-robots

License: CC-by-2.0

